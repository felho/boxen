# Better Touch Tool Puppet Module for Boxen

## Usage

```puppet
include bettertouchtool
```

## Required Puppet Modules

* boxen
