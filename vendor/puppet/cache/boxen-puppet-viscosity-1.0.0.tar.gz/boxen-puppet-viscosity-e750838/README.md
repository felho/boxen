# Viscosity Puppet Module for Boxen

## Usage

```puppet
include viscosity
```

## Required Puppet Modules

None.
